package com.example.bankingapplication.controller;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.scene.Node;

import java.io.IOException;

public class ViewsAccountsController {

    @FXML
    private TextArea accountDetailsArea;

    private String customerName;

    public void setCustomerName(String name) {
        this.customerName = name;
        refreshAccountDetails(); // Update after name is set
    }

    @FXML
    public void initialize() {
        // Placeholder, real update is in setCustomerName
    }

    public void refreshAccountDetails() {
        StringBuilder sb = new StringBuilder();
        sb.append("Account Details for ").append(customerName).append(":\n\n");

        sb.append("Savings Account:\n");
        sb.append("Account Number: SA001\n");
        sb.append("Balance: ").append(AccountData.savingsBalance).append("\n");

        sb.append("Current Account:\n");
        sb.append("Account Number: CA001\n");
        sb.append("Balance: ").append(AccountData.currentBalance).append("\n");

        accountDetailsArea.setText(sb.toString());
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/bankingapplication/dashboard.fxml"));
            Parent root = loader.load();

            DashboardController controller = loader.getController();
            controller.setCustomerName(customerName);

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
