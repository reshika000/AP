package com.example.bankingapplication.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.event.ActionEvent;
import javafx.scene.Node;

import java.io.IOException;

public class DashboardController {

    @FXML
    private Label welcomeLabel;


    private String customerName;

    public void setCustomerName(String name) {
        this.customerName = name;
        welcomeLabel.setText("Welcome, " + name + "!");
    }

    @FXML
    private void handleDeposit(ActionEvent event) {
        switchScene(event, "Deposit.fxml");
    }

    @FXML
    private void handleWithdraw(ActionEvent event) {
        switchScene(event, "Withdraw.fxml");
    }

    @FXML
    private void handleViewAccounts(ActionEvent event) {
        switchScene(event, "ViewAccounts.fxml");
    }

    @FXML
    private void handleAddInterest(ActionEvent event) {
        switchScene(event, "AddInterest.fxml");
    }


    @FXML
    private void handleExit(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Confirmation");
        alert.setHeaderText(null);
        alert.setContentText("Do you want to exit?");


        if (alert.showAndWait().get() == ButtonType.OK) {

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        }
    }

    private void switchScene(ActionEvent event, String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/bankingapplication/" + fxmlFile));
            Parent root = loader.load();


            Object controller = loader.getController();
            try {
                controller.getClass().getMethod("setCustomerName", String.class).invoke(controller, customerName);
            } catch (Exception ignored) {

            }

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
