package com.example.bankingapplication.controller;

public class AccountData {
    public static double savingsBalance = 5000.0;
    public static double currentBalance = 10000.0;
}


