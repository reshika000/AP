
package com.example.bankingapplication.controller;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.event.ActionEvent;
import javafx.scene.Node;

import java.io.IOException;

public class DepositController {

    @FXML
    private ComboBox<String> accountTypeComboBox;

    @FXML
    private TextField amountField;

    private String customerName;

    public void setCustomerName(String name) {
        this.customerName = name;
    }

    @FXML
    public void initialize() {
        accountTypeComboBox.getItems().addAll("Savings", "Current");
    }

    @FXML
    private void handleDeposit(ActionEvent event) {
        String accountType = accountTypeComboBox.getValue();
        String amountText = amountField.getText();

        if (accountType == null || amountText.isEmpty()) {
            showAlert("Please select account type and enter amount.");
            return;
        }

        try {
            double amount = Double.parseDouble(amountText);
            if (amount <= 0) {
                showAlert("Amount must be positive.");
                return;
            }

            // Update balances in memory
            if (accountType.equals("Savings")) {
                AccountData.savingsBalance += amount;
            } else if (accountType.equals("Current")) {
                AccountData.currentBalance += amount;
            }

            showAlert("Deposited " + amount + " to " + accountType + " account.");
            amountField.clear();

        } catch (NumberFormatException e) {
            showAlert("Invalid amount entered.");
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/bankingapplication/dashboard.fxml"));
            Parent root = loader.load();

            DashboardController controller = loader.getController();
            controller.setCustomerName(customerName);

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Deposit Info");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
