package com.example.bankingapplication.model;

public class Account {
    private String holderName;
    private double balance;

    public Account(String holderName) {
        this.holderName = holderName;
        this.balance = 0.0;
    }

    public String getHolderName() {
        return holderName;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }
}
