package com.example.bankingapplication.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.event.ActionEvent;
import javafx.scene.Node;

import java.io.FileWriter;
import java.io.IOException;

public class InterestController {

    private String customerName;

    public void setCustomerName(String name) {
        this.customerName = name;
    }

    @FXML
    private void handleAddInterest(ActionEvent event) {
        double interestRate = 0.05; // 5% interest
        double savingsBalance = AccountData.savingsBalance;
        double interestAmount = savingsBalance * interestRate;
        AccountData.savingsBalance += interestAmount;

        // Save balances to CSV
        saveBalances();


        showAlert("Interest of " + interestAmount + " added to Savings Account.\nNew Balance: " + AccountData.savingsBalance);
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/bankingapplication/dashboard.fxml"));
            Parent root = loader.load();

            DashboardController controller = loader.getController();
            controller.setCustomerName(customerName);

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveBalances() {
        try (FileWriter writer = new FileWriter("balances.csv")) {
            writer.write("SA001," + AccountData.savingsBalance + "\n");
            writer.write("CA001," + AccountData.currentBalance + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Interest Info");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
