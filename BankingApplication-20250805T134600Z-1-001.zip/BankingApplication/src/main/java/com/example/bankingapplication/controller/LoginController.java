package com.example.bankingapplication.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.event.ActionEvent;
import javafx.scene.Node;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    @FXML
    private void handleLogin(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Please enter both username and password.");
            return;
        }

        if (validateUser(username, password)) {
            try {
                // TODO: Replace "dashboard.fxml" with your actual dashboard FXML path
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/bankingapplication/dashboard.fxml"));
                Parent root = loader.load();

                // Optional: if your dashboard controller needs username, set here
                // DashboardController controller = loader.getController();
                // controller.setCustomerName(username);

                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.setTitle("Dashboard - Welcome " + username);
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
                showAlert("Failed to load dashboard.");
            }
        } else {
            showAlert("Invalid username or password.");
        }
    }

    private boolean validateUser(String username, String password) {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(getClass().getResourceAsStream("/com/example/bankingapplication/users.csv")))) {

            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String fileUser = parts[0].trim();
                    String filePass = parts[1].trim();
                    if (fileUser.equals(username) && filePass.equals(password)) {
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Login Error");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
