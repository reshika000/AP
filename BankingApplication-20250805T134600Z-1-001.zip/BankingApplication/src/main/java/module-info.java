
module com.example.bankingapplication {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.example.bankingapplication to javafx.fxml;
    opens com.example.bankingapplication.controller to javafx.fxml;

    exports com.example.bankingapplication;
    exports com.example.bankingapplication.controller;

}
